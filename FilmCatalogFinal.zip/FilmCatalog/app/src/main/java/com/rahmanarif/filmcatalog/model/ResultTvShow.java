package com.rahmanarif.filmcatalog.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResultTvShow {
    @SerializedName("results")
    @Expose
    private List<TvShow> results = null;

    public List<TvShow> getResults() {
        return results;
    }

    public void setResults(List<TvShow> results) {
        this.results = results;
    }

}
